# UI/UX Navigation Restructure Spec

> **Version**: Targets DE-LIMP v3.0 (modular architecture, ~7,200 lines, 15 files)
> **Mockup**: `delimp-nav-mockup-v5.html` — interactive reference for all layouts
> **Goal**: Reduce 13 flat top-level tabs → 5 grouped nav items with progressive reveal
> **Date**: February 2026

---

## Table of Contents

1. [Problem & Goals](#1-problem--goals)
2. [Navigation Architecture](#2-navigation-architecture)
3. [Phase 1: Nav Restructure & QC Merge](#3-phase-1-nav-restructure--qc-merge)
4. [Phase 2: Tab Renames & Moves](#4-phase-2-tab-renames--moves)
5. [Phase 3: Progressive Reveal](#5-phase-3-progressive-reveal)
6. [Phase 4: UI Controls (Help, Fullscreen, Export)](#6-phase-4-ui-controls)
7. [Phase 5: New Panels (PCA, Settings Modal)](#7-phase-5-new-panels)
8. [Sidebar Restructure](#8-sidebar-restructure)
9. [Files to Modify](#9-files-to-modify)
10. [Session Save/Load Compatibility](#10-session-saveload-compatibility)
11. [Testing Checklist](#11-testing-checklist)
12. [CLAUDE.md Updates](#12-claudemd-updates)

---

## 1. Problem & Goals

### Current State

The app has 13+ flat top-level tabs in `page_sidebar()`:

```
Data Overview | QC Trends | QC Plots | DE Dashboard | Consistent DE |
Reproducibility | Phosphoproteomics | Gene Set Enrichment | Multi-Omics MOFA2 |
Data Chat | Education | + New Search (conditional) | + Instrument QC (facility)
```

**Problems:**
- Overwhelming for bench scientists seeing the app for the first time
- "QC Trends" vs "QC Plots" distinction is an implementation detail, not a user concept
- "Consistent DE", "Reproducibility", "Data Chat" are opaque names
- No progressive reveal — all 13 tabs visible immediately, most non-functional before pipeline runs
- No clear workflow guidance (what do I click first?)

### Target State

5 top-level nav items (6 with facility mode), grouped by workflow phase:

```
Search | QC | Analysis ▾ | Output ▾ | Education | Facility ▾ (conditional)
```

- Before data loaded: 3 items visible (Search, Analysis→Data Overview, Education)
- After pipeline: QC, DE results, GSEA, Output revealed
- After phospho detection: Phosphoproteomics appears in Analysis dropdown
- Core facility mode: Facility dropdown appears

---

## 2. Navigation Architecture

### Top-Level Nav Structure

```r
page_sidebar(
  title = "DE-LIMP Proteomics",
  theme = bs_theme(bootswatch = "flatly"),
  # ... sidebar ...

  # === SEARCH (conditional) ===
  nav_panel("Search", icon = icon("rocket"), value = "search_tab",
    # existing search content
  ),

  # === QC (standalone, merged) ===
  nav_panel("QC", icon = icon("chart-bar"), value = "qc_tab",
    # merged QC Trends + QC Plots content (see Phase 1)
  ),

  # === ANALYSIS (dropdown menu) ===
  nav_menu("Analysis", icon = icon("microscope"), value = "analysis_menu",
    # -- Setup section --
    nav_panel("Data Overview", icon = icon("database"), value = "data_overview_tab",
      # existing Data Overview content
    ),
    nav_spacer(),  # visual divider
    # -- Results section --
    nav_panel("DE Dashboard", icon = icon("chart-scatter-bubble"), value = "de_tab",
      # existing DE Dashboard + Robust Changes sub-tab + PCA sub-tab
    ),
    nav_panel("Phosphoproteomics", icon = icon("flask"), value = "phospho_tab",
      # existing Phospho content (conditional on phospho_detected)
    ),
    nav_panel("Gene Set Enrichment", icon = icon("layer-group"), value = "gsea_tab",
      # existing GSEA content
    ),
    nav_panel("Multi-Omics MOFA2", icon = icon("cubes"), value = "mofa_tab",
      # existing MOFA content
    ),
    nav_spacer(),
    # -- Inspection section --
    nav_panel("XIC Viewer", icon = icon("wave-square"), value = "xic_tab",
      # existing XIC content (conditional on local/HPC)
    ),
    nav_spacer(),
    # -- AI section --
    nav_panel("AI Analysis", icon = icon("robot"), value = "ai_tab",
      # existing Data Chat content, renamed
    ),
  ),

  # === OUTPUT (dropdown menu) ===
  nav_menu("Output", icon = icon("file-export"), value = "output_menu",
    nav_panel("Methods & Code", icon = icon("scroll"), value = "methods_tab",
      # existing Reproducibility content, renamed
    ),
    nav_panel("Share Results", icon = icon("share-from-square"), value = "share_tab",
      # facility only — HTML report generation + live links
    ),
  ),

  # === EDUCATION (standalone) ===
  nav_panel("Education", icon = icon("graduation-cap"), value = "education_tab",
    # existing Education content
  ),

  # === FACILITY (conditional dropdown) ===
  nav_menu("Facility", icon = icon("building"), value = "facility_menu",
    nav_panel("Instrument QC", icon = icon("heartbeat"), value = "instrument_qc_tab", ...),
    nav_panel("Job Queue", icon = icon("list-check"), value = "job_queue_tab", ...),
    nav_panel("Templates", icon = icon("clone"), value = "templates_tab", ...),
  ),
)
```

### bslib `nav_menu()` Notes

- `nav_menu()` creates a dropdown in bslib's `page_sidebar()` — items appear as a dropdown when the parent is clicked
- `nav_spacer()` inside `nav_menu()` creates a visual divider between sections
- Each `nav_panel()` inside `nav_menu()` has its own `value` for `nav_select()` programmatic switching
- The dropdown label ("Analysis", "Output", etc.) is not itself a navigable tab — clicking it opens the dropdown

---

## 3. Phase 1: Nav Restructure & QC Merge

**Priority: P0 — do this first, everything else builds on it**

### 3.1 Merge QC Trends + QC Plots into Single QC Tab

The current app has two separate tabs:
- **QC Trends** (`qc_trends_tabs` navset): Precursors, Proteins, MS1 Signal, Stats Table
- **QC Plots** (`qc_subtabs` navset): Normalization Diagnostic, DPC Fit, MDS, Group Distribution (CV Histogram), P-value

Merge into a single `navset_card_tab` with two visual groups:

```r
nav_panel("QC", icon = icon("chart-bar"), value = "qc_tab",
  # Global sort control (from QC Trends)
  div(style = "background-color: #f8f9fa; padding: 10px; border-radius: 5px; margin-bottom: 15px;",
    div(style = "display: flex; align-items: center; justify-content: space-between;",
      div(style = "display: flex; align-items: center; gap: 15px;",
        icon("sort", style = "color: #6c757d;"),
        strong("Sort Order:"),
        radioButtons("qc_sort_order", NULL,
          choices = c("Run Order", "Group"), inline = TRUE, selected = "Run Order"
        )
      ),
      actionButton("qc_help_btn", icon("question-circle"),
        title = "QC Metrics Help", class = "btn-outline-info btn-sm")
    )
  ),

  navset_card_tab(
    id = "qc_merged_tabs",

    # ── Sample Metrics group ──
    nav_panel("Precursors", icon = icon("dna"),
      div(style = "display: flex; justify-content: flex-end; gap: 8px; margin-bottom: 10px;",
        actionButton("help_precursors", icon("question-circle"), class = "btn-outline-info btn-sm"),
        actionButton("png_precursors", icon("image"), class = "btn-outline-secondary btn-sm"),
        actionButton("fs_precursors", "\U0001F50D Fullscreen", class = "btn-outline-secondary btn-sm")
      ),
      plotlyOutput("qc_trend_plot_precursors", height = "calc(100vh - 380px)")
    ),
    nav_panel("Proteins", icon = icon("shapes"),
      # same pattern: help + PNG + fullscreen
      plotlyOutput("qc_trend_plot_proteins", height = "calc(100vh - 380px)")
    ),
    nav_panel("MS1 Signal", icon = icon("signal"),
      plotlyOutput("qc_trend_plot_ms1", height = "calc(100vh - 380px)")
    ),
    nav_panel("Stats Table", icon = icon("table"),
      DTOutput("r_qc_table")
    ),

    # ── Visual divider ──
    nav_spacer(),

    # ── Diagnostics group ──
    nav_panel("Normalization", icon = icon("stethoscope"),
      # existing normalization diagnostic content from QC Plots
      uiOutput("norm_diag_guidance"),
      # ... controls, plot ...
    ),
    nav_panel("DPC Fit", icon = icon("chart-line"),
      # existing DPC fit content
    ),
    nav_panel("MDS", icon = icon("arrows-to-dot"),
      # existing MDS plot content
    ),
    nav_panel("Group Dist.", icon = icon("users"),
      # existing CV histogram / group distribution content
    ),
    nav_panel("P-value", icon = icon("chart-area"),
      # existing p-value histogram content
    ),
  )
)
```

### 3.2 Server Module Consolidation

Currently `server_qc.R` handles both QC Trends and QC Plots. No server file split is needed — just update the UI tab IDs.

**Changes in `server_qc.R`:**
- All existing outputs (`qc_trend_plot_precursors`, `qc_trend_plot_proteins`, `qc_trend_plot_ms1`, `r_qc_table`, `norm_diag_*`, `dpc_fit_plot`, `mds_plot`, `cv_histogram`, `pvalue_histogram`) remain unchanged
- Fullscreen observers already exist — keep them, just ensure button IDs match new UI
- The `qc_trends_tabs` and `qc_subtabs` navset IDs become `qc_merged_tabs` — update any `updateTabsetPanel()` or `nav_select()` calls that reference these IDs

### 3.3 Restructure build_ui() Top-Level Nav

Replace the flat `nav_panel()` sequence with `nav_menu()` groupings as shown in Section 2.

**Key**: The existing tab `value` strings (`"de_tab"`, `"gsea_tab"`, etc.) should be preserved to avoid breaking any `nav_select()` calls in server modules.

---

## 4. Phase 2: Tab Renames & Moves

**Priority: P1**

### 4.1 Consistent DE → Robust Changes (sub-tab in DE Dashboard)

Currently "Consistent DE" is a top-level tab with its own `navset_card_tab`. Move it to be a sub-tab within DE Dashboard's `navset_card_tab`:

```r
# DE Dashboard navset_card_tab gains a new sub-tab:
nav_panel("Robust Changes", icon = icon("check-double"),
  # existing consistent DE content:
  # - upset plot
  # - consistent DE table
)
```

**Server impact:** `server_de.R` already handles all DE outputs. The consistent DE observers and renderers stay in `server_de.R`. Just update UI references.

### 4.2 Reproducibility → Methods & Code (under Output)

Rename and move to the Output dropdown:

```r
nav_panel("Methods & Code", icon = icon("scroll"), value = "methods_tab",
  navset_card_tab(
    nav_panel("Methods Summary",  # was "Methodology"
      # existing methodology_text output
    ),
    nav_panel("R Code Log",  # was "Code Log"
      # existing reproducible_code output + download button
    )
  )
)
```

**Server impact:** All outputs (`methodology_text`, `reproducible_code`, `download_repro_log`) are in `server_session.R` or `server_data.R`. No changes needed.

### 4.3 Data Chat → AI Analysis (under Analysis)

Rename and move from top-level to Analysis dropdown:

```r
nav_panel("AI Analysis", icon = icon("robot"), value = "ai_tab",
  # existing Data Chat content
  # Add link to Settings for API key configuration
  # Add "no API key" state (see Phase 5)
)
```

**Server impact:** `server_ai.R` handles all chat functionality. No changes needed.

### 4.4 Group QC Summary → Replicate Consistency (in Data Overview)

In Data Overview's `navset_card_tab`, rename the sub-tab:

```r
# was: nav_panel("Group QC Summary", ...)
nav_panel("Replicate Consistency", icon = icon("arrows-to-circle"),
  # existing group QC summary content — per-group CVs, protein counts, completeness
)
```

---

## 5. Phase 3: Progressive Reveal

**Priority: P2**

### Concept

Tabs are hidden until the relevant data/pipeline state exists. This uses bslib's `nav_select()` combined with `shinyjs::show()`/`hide()` or conditional rendering.

### Implementation Strategy

Use `conditionalPanel()` or dynamically show/hide nav items via `nav_show()`/`nav_hide()` (bslib >= 0.6.0). Check bslib version — if `nav_show`/`nav_hide` are not available, use CSS class toggling with `shinyjs`.

### Visibility Rules

```r
# In server (app.R or a dedicated server_nav.R module):

# After data upload (values$raw_data is set):
observe({
  if (!is.null(values$raw_data)) {
    # Show Data Overview is already visible
    # QC tab: show after data loaded (QC stats are computed on upload)
    nav_show(id = "main_nav", target = "qc_tab")
  }
})

# After pipeline runs (values$fit is set):
observe({
  if (!is.null(values$fit)) {
    nav_show(id = "main_nav", target = "de_tab")
    nav_show(id = "main_nav", target = "gsea_tab")
    nav_show(id = "main_nav", target = "mofa_tab")
    nav_show(id = "main_nav", target = "methods_tab")
  }
})

# After phospho detection:
observe({
  if (isTRUE(values$phospho_detected$detected)) {
    nav_show(id = "main_nav", target = "phospho_tab")
  }
})

# XIC viewer: show only when local/HPC and XIC files loaded
observe({
  if (isTRUE(values$xic_available)) {
    nav_show(id = "main_nav", target = "xic_tab")
  }
})

# Core facility mode:
if (is_core_facility) {
  # Facility dropdown shown at startup
} else {
  nav_hide(id = "main_nav", target = "facility_menu")
}

# Search tab:
if (search_enabled) {
  # Show at startup
} else {
  nav_hide(id = "main_nav", target = "search_tab")
}
```

### Initial State (before any data)

Visible: Search (if enabled), Data Overview (in Analysis), Education
Hidden: QC, DE Dashboard, Phospho, GSEA, MOFA2, XIC, AI Analysis, Output, Facility

### Fallback (if nav_show/nav_hide unavailable)

Use `shinyjs` with CSS:

```r
# In server:
observe({
  if (is.null(values$fit)) {
    shinyjs::runjs("$('[data-value=\"de_tab\"]').parent().hide();")
  } else {
    shinyjs::runjs("$('[data-value=\"de_tab\"]').parent().show();")
  }
})
```

---

## 6. Phase 4: UI Controls (Help, Fullscreen, Export)

**Priority: P2**

### 6.1 Consistent Help Buttons

Every panel/plot area gets a `?` help button that opens a modal with contextual explanation. Pattern:

```r
# UI:
actionButton("help_<panel>", icon("question-circle"),
  title = "What am I looking at?", class = "btn-outline-info btn-sm")

# Server:
observeEvent(input$help_<panel>, {
  showModal(modalDialog(
    title = "<Panel Name> — Help",
    # content explaining what this panel shows and how to interpret it
    easyClose = TRUE, footer = modalButton("Close"), size = "l"
  ))
})
```

**Panels needing help buttons** (most already exist, verify all are present):
- QC: each sub-tab (Precursors, Proteins, MS1, Normalization, DPC Fit, MDS, Group Dist., P-value)
- DE Dashboard: Volcano, Results Table, Violin, PCA, Robust Changes
- Phospho: Phospho Volcano, Site Table
- GSEA: Dot Plot, Results Table
- MOFA: Variance, Weights
- XIC Viewer: Chromatograms
- Instrument QC (facility)

### 6.2 Consistent Fullscreen Buttons

Every plot gets a fullscreen button. Two approaches (choose one):

**Option A: bslib native `full_screen = TRUE`** (preferred if using bslib >= 0.6.0):
```r
card(full_screen = TRUE,
  card_body(
    plotlyOutput("volcano_plot", height = "calc(100vh - 380px)")
  )
)
```

**Option B: Modal-based fullscreen** (current approach, works everywhere):
```r
# UI:
actionButton("fs_<plot>", "\U0001F50D Fullscreen", class = "btn-outline-secondary btn-sm")

# Server:
observeEvent(input$fs_<plot>, {
  showModal(modalDialog(
    title = "<Plot> — Fullscreen",
    plotlyOutput("<plot>_fs", height = "700px"),
    size = "xl", easyClose = TRUE, footer = modalButton("Close")
  ))
})
```

**Recommendation**: Use Option A (bslib native) for new panels, keep Option B for existing panels to avoid breaking changes. Migrate incrementally.

### 6.3 Consistent Export Controls

Every results panel gets an export bar at the bottom. Standard pattern:

```r
div(style = "display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px; padding-top: 12px; border-top: 1px solid #f0f0f0;",
  # PNG export (for plots):
  downloadButton("png_<plot>", icon("image"), class = "btn-outline-secondary btn-sm"),
  # Data export (CSV):
  downloadButton("export_<panel>_csv", label = tagList(icon("download"), " Export CSV"),
    class = "btn-success btn-sm"),
  # Skyline export (DE Dashboard, Phospho, XIC):
  downloadButton("export_skyline_tsv", label = tagList(icon("crosshairs"), " Skyline TSV"),
    class = "btn-primary btn-sm"),
)
```

**Panels needing export bars:**

| Panel | Exports |
|-------|---------|
| DE Dashboard | Export CSV, Skyline TSV, Skyline Bundle |
| Phospho | Export Site Table |
| GSEA | Export GSEA Table |
| XIC Viewer | Send to Skyline, Export Fragment Data |
| Data Overview | Export Metadata CSV |
| Methods & Code | Copy Methods, Download R Script |

Most of these already exist — verify and standardize button styling.

---

## 7. Phase 5: New Panels (PCA, Settings Modal)

**Priority: P3**

### 7.1 PCA Sub-Tab in DE Dashboard

Add a PCA plot as a new sub-tab in DE Dashboard's `navset_card_tab`, between Violin Plots and Robust Changes.

```r
nav_panel("PCA", icon = icon("compass"),
  div(style = "display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin-bottom: 12px;",
    div(
      tags$label("Color by:", style = "font-size: 0.8rem; font-weight: 600;"),
      selectInput("pca_color_by", NULL,
        choices = c("Group (Condition)" = "Group"),  # dynamically populated from metadata columns
        width = "180px"
      )
    ),
    div(
      tags$label("Shape by:", style = "font-size: 0.8rem; font-weight: 600;"),
      selectInput("pca_shape_by", NULL,
        choices = c("None" = "none"),  # dynamically populated
        width = "140px"
      )
    ),
    div(
      tags$label("Axes:", style = "font-size: 0.8rem; font-weight: 600;"),
      selectInput("pca_axes", NULL,
        choices = c("PC1 vs PC2" = "1_2", "PC1 vs PC3" = "1_3", "PC2 vs PC3" = "2_3"),
        width = "140px"
      )
    ),
    div(style = "margin-left: auto; display: flex; gap: 6px;",
      actionButton("help_pca", icon("question-circle"), class = "btn-outline-info btn-sm"),
      downloadButton("png_pca", icon("image"), class = "btn-outline-secondary btn-sm"),
      actionButton("fs_pca", "\U0001F50D Fullscreen", class = "btn-outline-secondary btn-sm")
    )
  ),
  plotlyOutput("pca_plot", height = "calc(100vh - 380px)")
)
```

**Server logic** (add to `server_de.R` or new `server_pca.R`):

```r
# Compute PCA from protein-level expression matrix
pca_result <- reactive({
  req(values$y_protein)
  mat <- values$y_protein$E
  # Remove rows with any NA
  mat_complete <- mat[complete.cases(mat), ]
  # Transpose: prcomp expects samples as rows
  pca <- prcomp(t(mat_complete), center = TRUE, scale. = TRUE)
  pca
})

# Dynamically populate color/shape selectors from metadata
observe({
  req(values$metadata)
  meta_cols <- c("Group")
  # Add any non-empty covariate columns
  for (col in c("Batch", "Covariate1", "Covariate2")) {
    if (col %in% names(values$metadata) && any(values$metadata[[col]] != "")) {
      meta_cols <- c(meta_cols, col)
    }
  }
  updateSelectInput(session, "pca_color_by", choices = meta_cols)
  updateSelectInput(session, "pca_shape_by", choices = c("None" = "none", meta_cols))
})

# Render PCA plot
output$pca_plot <- renderPlotly({
  req(pca_result(), values$metadata)
  pca <- pca_result()
  axes <- strsplit(input$pca_axes, "_")[[1]]
  pc_x <- as.integer(axes[1])
  pc_y <- as.integer(axes[2])

  # Build plot data frame
  scores <- as.data.frame(pca$x[, c(pc_x, pc_y)])
  colnames(scores) <- c("PC_X", "PC_Y")
  scores$Sample <- rownames(scores)

  # Match to metadata
  scores <- scores %>%
    left_join(values$metadata, by = c("Sample" = "File.Name"))

  var_explained <- summary(pca)$importance[2, ] * 100

  color_var <- input$pca_color_by
  p <- ggplot(scores, aes(x = PC_X, y = PC_Y, color = .data[[color_var]],
              text = paste("Sample:", Sample))) +
    geom_point(size = 3, alpha = 0.8) +
    stat_ellipse(level = 0.95, linetype = "dashed") +
    labs(
      x = sprintf("PC%d (%.1f%%)", pc_x, var_explained[pc_x]),
      y = sprintf("PC%d (%.1f%%)", pc_y, var_explained[pc_y])
    ) +
    theme_minimal()

  if (input$pca_shape_by != "none") {
    p <- p + aes(shape = .data[[input$pca_shape_by]])
  }

  ggplotly(p, tooltip = "text")
})
```

### 7.2 Settings Modal (Navbar Gear Icon)

Add a settings gear icon to the navbar and a modal for global configuration.

**UI** (in `build_ui()`):

```r
# Add custom CSS/JS for settings gear in navbar
tags$head(tags$script(HTML("
  $(document).ready(function() {
    // Add settings gear to navbar
    var gear = '<div class=\"nav-settings\" onclick=\"Shiny.setInputValue(\\\"open_settings\\\", Math.random())\" style=\"margin-left:auto;cursor:pointer;padding:8px 10px;color:rgba(255,255,255,0.6);\" title=\"Settings\"><i class=\"fa-solid fa-gear\"></i></div>';
    $('.navbar .container-fluid').append(gear);
  });
")))
```

**Server** (in `server_ai.R` or new `server_settings.R`):

```r
observeEvent(input$open_settings, {
  showModal(modalDialog(
    title = tagList(icon("gear"), " Settings"),
    size = "m",

    # Gemini API Key
    tags$label(icon("robot"), " Gemini API Key"),
    passwordInput("gemini_api_key_setting", NULL,
      value = if (!is.null(values$gemini_api_key)) "••••••••" else "",
      placeholder = "Paste your API key"
    ),
    tags$p(class = "text-muted small",
      "Required for AI Analysis. Get a key at ",
      tags$a(href = "https://ai.google.dev", target = "_blank", "ai.google.dev")
    ),

    # Theme (future)
    # selectInput("app_theme", "Theme", choices = c("Flatly", "Darkly")),

    footer = tagList(
      modalButton("Cancel"),
      actionButton("save_settings", "Save", class = "btn-success", icon = icon("check"))
    )
  ))
})

observeEvent(input$save_settings, {
  if (nzchar(input$gemini_api_key_setting) && input$gemini_api_key_setting != "••••••••") {
    values$gemini_api_key <- input$gemini_api_key_setting
  }
  removeModal()
  showNotification("Settings saved", type = "success")
})
```

**AI Analysis — No Key State:**

In the AI Analysis panel, if no API key is configured, show a setup prompt instead of the chat:

```r
output$ai_chat_content <- renderUI({
  if (is.null(values$gemini_api_key) || !nzchar(values$gemini_api_key)) {
    # No key configured
    div(style = "text-align: center; padding: 60px 20px;",
      icon("robot", style = "font-size: 3rem; color: #c4b5fd; margin-bottom: 16px;"),
      h4("Set Up AI Analysis"),
      p(class = "text-muted", "Enter your Gemini API key to start asking questions about your data."),
      actionButton("open_settings_from_ai", "Configure API Key",
        class = "btn-primary", icon = icon("gear"))
    )
  } else {
    # Existing chat UI
    tagList(
      uiOutput("chat_window"),
      # ... chat input ...
    )
  }
})
```

---

## 8. Sidebar Restructure

### Accordion Sections

Convert sidebar from flat layout to collapsible accordion sections:

```r
sidebar = sidebar(
  width = 300,

  # Section 1: Data Input (open by default)
  accordion(
    id = "sidebar_accordion",
    open = "upload",  # only Upload open initially

    accordion_panel("Upload Data", value = "upload", icon = icon("file-arrow-up"),
      fileInput("report_file", NULL, accept = ".parquet", placeholder = "Choose report.parquet"),
      fileInput("metadata_file", NULL, accept = ".csv", placeholder = "metadata.csv (optional)"),
      actionButton("load_example", "Load Example Data", class = "btn-outline-secondary btn-sm", width = "100%")
    ),

    accordion_panel("Pipeline Settings", value = "pipeline", icon = icon("sliders"),
      # existing pipeline controls: normalization, FDR, logFC
    ),

    accordion_panel("Phospho & XIC", value = "phospho_xic", icon = icon("flask"),
      # existing phospho sidebar controls + XIC directory
    ),

    accordion_panel("Session", value = "session", icon = icon("floppy-disk"),
      div(style = "display: flex; gap: 8px;",
        downloadButton("save_session", "Save", class = "btn-outline-secondary btn-sm", style = "flex:1;"),
        actionButton("load_session_btn", "Load", class = "btn-outline-secondary btn-sm", style = "flex:1;")
      )
    ),

    # Conditional: Core Facility
    if (is_core_facility) {
      accordion_panel("Core Facility", value = "facility_sidebar", icon = icon("building"),
        # staff selector, HPC status
      )
    }
  )
)
```

---

## 9. Files to Modify

### Primary Changes

| File | Changes | Effort |
|------|---------|--------|
| `R/ui.R` | **Major rewrite of `build_ui()` nav structure.** Replace flat `nav_panel()` list with `nav_menu()` groupings. Merge QC tabs. Move Consistent DE into DE Dashboard. Move Reproducibility to Output. Rename Data Chat. Add PCA sub-tab. Add Settings gear. Restructure sidebar to accordion. | ~4 hrs |
| `R/server_qc.R` | Update tab ID references from `qc_trends_tabs`/`qc_subtabs` to `qc_merged_tabs`. No logic changes. | 30 min |
| `R/server_de.R` | Add PCA reactive, renderer, color/shape selectors. Add fullscreen handler for PCA. Verify Consistent DE outputs still work in new sub-tab location. | 1.5 hrs |
| `R/server_ai.R` | Add Settings modal handler. Add no-key-state UI. Add `open_settings_from_ai` button handler. | 1 hr |
| `app.R` | Add progressive reveal observers. Add `nav_show()`/`nav_hide()` calls. | 1 hr |

### Minor Changes

| File | Changes | Effort |
|------|---------|--------|
| `R/server_session.R` | Verify session save/load works with renamed tab values. | 30 min |
| `R/server_data.R` | Ensure `nav_select()` calls after pipeline runs point to new tab values. | 15 min |
| `R/server_search.R` | Verify search tab conditional logic works with new nav structure. | 15 min |
| `R/server_viz.R` | Rename "Group QC Summary" sub-tab output to "Replicate Consistency". | 15 min |
| `CLAUDE.md` | Update tab structure documentation. | 30 min |
| `USER_GUIDE.md` | Update navigation instructions and screenshots. | 1 hr |

### New Files (optional)

| File | Purpose | Lines (est.) |
|------|---------|-------------|
| `R/server_nav.R` | Progressive reveal logic, settings modal, nav state management | ~200 |

**Estimated total: ~10 hours**

---

## 10. Session Save/Load Compatibility

### Tab Value Mapping

If any `values$active_tab` or `nav_select()` calls use old tab names, they need updating:

| Old Value | New Value |
|-----------|-----------|
| `"qc_trends_tab"` | `"qc_tab"` |
| `"qc_plots_tab"` | `"qc_tab"` (merged) |
| `"consistent_de_tab"` | `"de_tab"` (sub-tab within DE Dashboard) |
| `"reproducibility_tab"` | `"methods_tab"` |
| `"data_chat_tab"` | `"ai_tab"` |

### Backward Compatibility

When loading old session files, map old tab values to new ones:

```r
# In session load handler:
tab_remap <- c(
  "qc_trends_tab" = "qc_tab",
  "qc_plots_tab" = "qc_tab",
  "consistent_de_tab" = "de_tab",
  "reproducibility_tab" = "methods_tab",
  "data_chat_tab" = "ai_tab"
)
if (saved_tab %in% names(tab_remap)) {
  saved_tab <- tab_remap[[saved_tab]]
}
```

---

## 11. Testing Checklist

### Phase 1: Nav Restructure & QC Merge
- [ ] All 5 top-level nav items render correctly
- [ ] Analysis dropdown shows all 7 items with section dividers
- [ ] Output dropdown shows Methods & Code and Share Results
- [ ] QC tab has all 9 sub-tabs with visual divider between Sample Metrics and Diagnostics
- [ ] All QC plots render in new merged tab (Precursors, Proteins, MS1, Stats, Norm, DPC, MDS, Group Dist., P-value)
- [ ] QC sort order control applies to all metric sub-tabs
- [ ] Normalization diagnostic guidance banner still appears correctly

### Phase 2: Renames & Moves
- [ ] "Robust Changes" appears as sub-tab in DE Dashboard (after Violin Plots)
- [ ] Upset plot and consistent DE table render correctly in new location
- [ ] "Methods & Code" appears in Output dropdown with Methods Summary + R Code Log sub-tabs
- [ ] Download Reproducibility Log still works
- [ ] Copy Methods button still works
- [ ] "AI Analysis" appears in Analysis dropdown
- [ ] Chat functionality works identically to old "Data Chat"
- [ ] "Replicate Consistency" label appears in Data Overview sub-tabs

### Phase 3: Progressive Reveal
- [ ] Before data upload: only Search, Data Overview, Education visible
- [ ] After data upload: QC tab appears
- [ ] After pipeline runs: DE Dashboard, GSEA, MOFA2, Output appear
- [ ] After phospho detection: Phosphoproteomics appears
- [ ] XIC Viewer only appears when XIC files loaded (local/HPC mode)
- [ ] Facility dropdown only appears in core facility mode
- [ ] Search tab only appears when search backends available

### Phase 4: UI Controls
- [ ] Help `?` button on every panel opens relevant modal
- [ ] Fullscreen button on every plot works (modal or bslib native)
- [ ] PNG export buttons download correct plot images
- [ ] Export CSV buttons on DE Dashboard, Phospho, GSEA work
- [ ] Skyline TSV and Bundle exports work from DE Dashboard

### Phase 5: New Panels
- [ ] PCA sub-tab renders scatter plot with confidence ellipses
- [ ] PCA color-by dynamically populates from metadata columns
- [ ] PCA shape-by works with "None" and metadata columns
- [ ] PCA axis selector switches between PC1/2, PC1/3, PC2/3
- [ ] PCA variance explained percentages are correct in axis labels
- [ ] Settings gear appears in navbar
- [ ] Settings modal opens with API key, saves correctly
- [ ] AI Analysis shows "no key" state when API key not set
- [ ] "Configure API Key" button in AI Analysis opens Settings modal

### Cross-cutting
- [ ] Session save/load works with new tab structure
- [ ] Old session files load correctly (tab value remapping)
- [ ] HF Spaces deployment: Search, XIC, Facility correctly hidden
- [ ] Local deployment: all features available
- [ ] Education tab remains prominent with yellow graduation cap icon
- [ ] Sidebar accordion sections collapse/expand correctly
- [ ] All existing `nav_select()` calls in server modules work with new tab values

---

## 12. CLAUDE.md Updates

After implementation, update the Main Tab Structure section in CLAUDE.md:

```markdown
## Main Tab Structure (v3.1 — Grouped Navigation)

### Top-Level Nav (5 items, 6 with facility mode)
- **Search** — DIA-NN search (conditional: Docker/HPC)
- **QC** — merged QC Trends + QC Plots, 9 sub-tabs in 2 groups
- **Analysis ▾** — dropdown menu:
  - Data Overview (Setup: groups, pipeline, metadata)
  - DE Dashboard (Results: Volcano+Heatmap, Results Table, Violin, PCA, Robust Changes)
  - Phosphoproteomics (conditional: auto-detected)
  - Gene Set Enrichment (BP/MF/CC/KEGG)
  - Multi-Omics MOFA2
  - XIC Viewer (conditional: local/HPC only)
  - AI Analysis (Gemini chat, renamed from Data Chat)
- **Output ▾** — dropdown menu:
  - Methods & Code (renamed from Reproducibility)
  - Share Results (facility only)
- **Education** — standalone, yellow graduation cap
- **Facility ▾** — conditional dropdown:
  - Instrument QC
  - Job Queue
  - Templates

### Progressive Reveal
- Before data: Search, Data Overview, Education (3 items)
- After upload: + QC
- After pipeline: + DE Dashboard, GSEA, MOFA2, Output
- After phospho: + Phosphoproteomics
- After XIC load: + XIC Viewer

### Settings
- Gear icon in navbar → modal with Gemini API key, theme
- AI Analysis shows setup prompt if no key configured
```
